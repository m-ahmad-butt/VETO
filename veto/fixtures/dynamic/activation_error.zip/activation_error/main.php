<?php
/*
Plugin Name: VETO Failure Controlled Runtime Fixture
Version: 1.0.0
*/
defined('ABSPATH') || exit;
register_activation_hook(__FILE__,function(){throw new RuntimeException('VETO controlled activation failure');});
