<?php
/*
Plugin Name: VETO Timeout Controlled Runtime Fixture
Version: 1.0.0
*/
defined('ABSPATH') || exit;
register_activation_hook(__FILE__,function(){sleep(60);});
